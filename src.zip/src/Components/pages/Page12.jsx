import React from 'react'
import Header from '../Header/Header'
import Components from '../headers/cardsCatalog/Components'

export default function Page12({data}) {
  return (
    <div>
        <Components data={data} />
        
    </div>
  )
}
