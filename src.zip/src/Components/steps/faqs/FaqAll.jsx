import React from 'react'
import Faq from './Faq'

export default function FaqAll() {
    return (
        <div>
            <section className='faqs'>
            <Faq >
            <h1>Часто задаваемые вопросы</h1>
            </Faq>
            <Faq />
            <Faq />
            <Faq />
            <Faq />
            </section>
          

        </div>
    )
}
