import cart from './img/Decorative Icons.png'
import dong from './img/Layer 1.png'
import cube from './img/Decorative Icons (1).png'
import location from './img/Decorative Icons (2).png'

let step = {
    cart:cart,
    dong:dong,
    cube:cube,
    location:location,
    cartText:'Добавьте нужные товары \nв корзину и оплатите заказ',
    dongText:'Получите уведомления о подтверждении вашего заказа',
    cubeText:'После подтверждения мы сформируем ваш заказ',
    locationText:'Заберите из пунктов выдачи'
}

export default step;