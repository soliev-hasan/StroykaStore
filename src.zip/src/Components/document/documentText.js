import sdelka from './img/Frame 4452.png'
import politika from './img/Frame 4453 (2).png'
import offerta from './img/Frame 4453 (1).png'

let documentText = {
    sdelka:sdelka,
    politika:politika,
    offerta:offerta,
    sdelkaText:'Оферта «Безопасная сделка»',
    politikaText:'Политика конфиденциальности ',
    offertaText:'Оферта доставки'

}

export default documentText;