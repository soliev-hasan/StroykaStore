import bever from './img/image 61.png'
import braer from './img/Frame 4184.png'
import stone from './img/image 59.png'
import block from './img/image 60.png'
import perfekta from './img/image 58.png'
import lcp from './img/image 63.png'
import galen from './img/image 62.png'
import recke from './img/image 64.png'
import mod from './img/image 65.png'
import decra from './img/image 66.png'
import mstera from './img/image 57.png'
import engels from './img/image 67.png'

let brands = {
    bever:bever,
    braer:braer,
    stone:stone,
    block:block,
    perfekta:perfekta,
    lcp:lcp,
    galen:galen,
    recke:recke,
    mod:mod,
    decra:decra,
    mstera:mstera,
    engels:engels,
    head:'Популярные бренды',
    btn:"Все бренды"
}

export default brands;