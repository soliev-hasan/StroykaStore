import React from 'react'
import './Brands.css'

export default function Brands(props) {
  return (
    <div>
      <img src={props.src} alt='' />
    </div>
  )
}
