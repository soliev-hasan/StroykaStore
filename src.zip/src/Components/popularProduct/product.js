import yasmin from './img/Image (4).png'
import cresit from './img/Image (5).png'
import gruntovka from './img/Image (6).png'
import gips from './img/Image (7).png'
import profil from './img/Image (8).png'
import ruletka from './img/Image (9).png'
import knaufShtukaturka from './img/Image (10).png'
import ugolok from './img/Image (11).png'
import knaufRotband from './img/Image (12).png'
import samorez from './img/Image (13).png'
import superFinish from './img/Image (14).png'
import scoth from './img/Image (15).png'





const popular = {
    yasmin:yasmin,
    descrition:'Керамогранит Yasmin 598х185 коричневый C-YA4M112D',
    cresit:cresit,
    descritpion1:'Затирка для узких швов Ceresit СЕ 33, цвет белый, 2 кг',
    gruntovka:gruntovka,
    descritpion2:'Грунтовка Старатели 10л глубокого проникновения',
    gips:gips,
    descritpion3:'Гипсокартон Волма, 2500 х 1200 х 12,5 мм',
    profil:profil,
    descritpion4:'Профиль 0,55мм для гипсокартона',
    ruletka:ruletka,
    descritpion5:'Рулетка 3м',
    knaufShtukaturka:knaufShtukaturka,
    descritpion6:'Кнауф Мп 75 штукатурка гипсовая МН 30кг',
    ugolok:ugolok,
    descritpion7:'Уголок серый канализационный Д110 ГР90',
    knaufRotband:knaufRotband,
    descritpion8:'Knauf Ротбанд, 30 кг',
    samorez:samorez,
    descritpion9:'Саморез по металлу 3,5х25 мм для гипсокартона',
    superFinish:superFinish,
    descritpion10:'Шпатлевка универсальная Danogips SuperFinish 17 л',
    scoth:scoth,
    descritpion11:'Клейкая лента металлизированная Изоспан FL 5х5000 см',
    price1:899,
    price2:275,
    price3:839,
    price4:335,
    price5:195,
    price6:100,
    price7:380,
    price8:508,
    price9:340,
    price10:2555,
    price11:"226",
}

export default popular;