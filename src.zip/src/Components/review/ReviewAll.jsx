import React from 'react'
import './Review.css'
import ReviewCard from './ReviewCard'
import reviewText from './reviewText'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons'
import { faArrowRight } from '@fortawesome/free-solid-svg-icons'
import { useRef } from 'react/cjs/react.development';

export default function ReviewAll() {
  const prev = useRef(),
        next = useRef();

  function prevSlide () {
    prev.current.classList.add('prev-slide')
  }
  function nextSlide () {
    if( prev.current.classList.contains('prev-slide')){
      prev.current.classList.remove('prev-slide')
      prev.current.style.transition ="1s"

    }
  }

    return (
        <div>
            <div className='review-section'>
            <div className="text-review">
            <h1>Отзывы</h1>
            <div class="button-review">
                <button onClick={prevSlide} className="fa fa-arrow-left"><FontAwesomeIcon icon={faArrowLeft}/></button>
                <button onClick={nextSlide} className="fa fa-arrow-right"><FontAwesomeIcon icon={faArrowRight}/></button>
            </div>
        </div>
        <div ref={prev} className='review-cards'>
                <ReviewCard
                src = {reviewText.petr}
                name = {reviewText.namePetr}
                text = {reviewText.reviewPetr}
                date = {reviewText.datePetr}
                />
                  <ReviewCard
                src = {reviewText.anna}
                name = {reviewText.NameAnna}
                text = {reviewText.reviewAnna}
                date = {reviewText.dateAnna}
                />
                  <ReviewCard
                src = {reviewText.victor}
                name = {reviewText.NameVictor}
                text = {reviewText.reviewVictor}
                date = {reviewText.dateVictor}
                />
                  <ReviewCard
                  
                src = {reviewText.dmitri}
                name = {reviewText.NameDmitri}
                text = {reviewText.reviewDmitri}
                date = {reviewText.dateDmitri}
                />
            </div>
            </div>
        </div>
    )
}
