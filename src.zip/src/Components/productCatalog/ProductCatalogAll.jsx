import React from 'react'
import { Link } from 'react-router-dom'
import { productCatalog } from '../../data'
import PopularProduct from '../popularProduct/PopularProduct'
import ProductCatalog from './ProductCatalog'
import './ProductCatalog.css'
import { useState, useRef } from 'react/cjs/react.development';
import { logDOM } from '@testing-library/react'
import popularCategories from './../categories/categoriesText';

export default function ProductCatalogAll({ data, filter, fil, fil2, setData, handleClick, modal, sortAlphabet,backgroundColor }) {

   
    const [search, setSearch] = useState('')

    function sear () {
        productCatalog.filter(el => {
            if (el.text.toLowerCase().indexOf(search) > -1) {
              return el
            } else {
               return el.text
            }
        }).map(el => (el))
        
    }

    return (
        <div>
            <div className='product-catalog '>

                <div className='filter'>
                    <p>Цена</p>
                    <div className='input-row'>
                        <input type="text" placeholder='1000' />
                        <input type="text" placeholder='100 000' />
                    </div>
                    <div className='brand-filter'>
                        <p>Бренд</p>
                        <input type="text" placeholder='Поиск' onInput={sear} onChange={e => setSearch(e.target.value)}  value={search} />
                        <div className='filter-brand'>
                            <input type="checkbox" />
                            <label htmlFor="">Braer</label><br />
                            <input type="checkbox" />
                            <label htmlFor="">Mstera</label><br />
                            <input type="checkbox" />
                            <label htmlFor="">Euroblock</label><br />
                            <input type="checkbox" />
                            <label htmlFor="">Гален</label><br />
                            <input type="checkbox" />
                            <label htmlFor="">ЛСР</label><br />
                            <input type="checkbox" />
                            <label htmlFor="">Decra</label><br />
                            <input type="checkbox" />
                            <label htmlFor="">Аксон</label><br />
                        </div>
                        <p>Поставщик</p>
                        <select name="" id="">
                            <option value="">Аксон</option>
                        </select>
                    </div>
                    <div className='btn-filter'>
                        <button className=' button-slide submit'>Применить</button>
                        <button className=' remove-filter'>Сбросить</button>
                    </div>

                </div>

                <div>
                    <div>
                        <form  className='filter-price' onSubmit={e => { e.preventDefault() }}>
                            <button onClick={() => setData(productCatalog)}>Все</button>
                            <button onClick={() => filter('yes')} >Популярные</button>
                            <button type='submit' onClick={() => fil()} >Дешевле</button>
                            <button type='submit' onClick={() => fil2()}>Дороже</button>
                            <button onClick={sortAlphabet}>По алфавиту</button>
                        </form>


                    </div>
                    <div className='catalog-cards'>
                        {

                            data.map((item, index) => (
                                <div>
                                    <PopularProduct modal={modal} handleClick={handleClick} key={item.id} data={item} item={item} />
                                </div>

                            ))
                        }
                    </div>
                </div>



            </div>
        </div>
    )
}
