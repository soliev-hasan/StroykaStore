import img from "./img/Image.png"
import img2 from "./img/Image (1).png"
import img3 from "./img/Image (2).png"
import img4 from "./img/Image (3).png"


let StockText = {
    src: img,
    text: 'Рубероид РКП-350 ТУ, размер материала 1 х 10 м (10м2, 1 рулон)',
    price: 449,
    sPrice: 499,
    src2: img2,
    text2: 'Пена монтажная ТЕХНОНИКОЛЬ MASTER 65 профессиональная всесезонная',
    price2: 495,
    sPrice2: 600,
    src3: img3,
    text3: 'Сетка "Рабица" яч. 50х50/1,5х10 м-ОЦ)',
    price3: 1499,
    sPrice3: 1890,
    src4: img4,
    text4: 'Металлочерепица, цвет коричневый, 1.18 х 1.15 м',
    price4: 769,
    sPrice4: 999,
    stock: {
        headStocks: 'Акции',
        buttonStocks: 'Все акции',
        headCategory: 'Популярные категории',
        buttonCategory: 'Все категории',
        headBrands: 'Акции',
        buttonBrands: 'Все акции'
    },
   
}
export default StockText;
