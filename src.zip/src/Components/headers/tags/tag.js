
const tag = [
    {
        id:1,
        brand:'Аксон',
    },
    {
        id:2,
        brand:'A-progress.ru',
    },
    {
        id:3,
        brand:'Дешево-Строй',
    },
    {
        id:4,
        brand:'ГдеМатериал',
    },
    {
        id:5,
        brand:'ГлавСнаб',
    },
    {
        id:6,
        brand:'Гермес Групп',
    },
    {
        id:7,
        brand:'Маркет-Строй',
    },
    {
        id:8,
        brand:'МосДоброСтрой',
    },
    {
        id:9,
        brand:'Сатурн ',
    },
    {
        id:10,
        brand:'Ремонт 3000',
    },
    {
        id:11,
        brand:'Roof&Facade',
    },
    {
        id:12,
        brand:'Строительный двор',
    },
    {
        id:13,
        brand:'Skladom.ru',
    },
    {
        id:14,
        brand:'Smart Complect',
    },
    {
        id:15,
        brand:'Конструктор',
    },
    {
        id:16,
        brand:'RDS Строй',
    },
    {
        id:17,
        brand:'Строительный Онлайн',
    },
    {
        id:18,
        brand:'Стройкомплект',
    },
    {
        id:19,
        brand:'Строительный Мир',
    },
    {
        id:20,
        brand:'Stroimaterial Moskva',
    },
    {
        id:21,
        brand:'Стройландия',
    },
    {
        id:22,
        brand:'Stroy Shopper',
    },
]

export default tag;
