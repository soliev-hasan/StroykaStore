import React from 'react'
import './Modals.css'
export default function SignUp(props) {
    return (
        <div>
            <br />
        </div>
    )
}
